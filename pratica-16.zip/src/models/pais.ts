export default class Pais {
    nome: string
    populacao: number

    constructor (nome: string, populacao: number) {
        this.nome = nome
        this.populacao = populacao
    } 
}