import { MongoClient } from 'mongodb'

const url = 'mongodb://Admin:admin@127.0.0.1:27017/devweb2'

const getMongoConn = async (): Promise<MongoClient> => {
    const client = new MongoClient(url);
    const conn = await client.connect();
    return conn;
}

export default getMongoConn