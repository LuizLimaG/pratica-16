import { MongoClient } from 'mongodb'
import getMongoConn from './db'
import Pais from './models/pais'

const paisArray: Pais[] = [
    new Pais('Bangladesh', 339_978_103),
    new Pais('Tunisia', 12_260_103),
    new Pais('Vaticano', 825),
    new Pais('Europa', 746_400_000),
    new Pais('Luxemburgo', 640_064),
    new Pais('Butao', 777_486)
]

const main = async () => {

    let conn: MongoClient | null = null

    try {
        conn = await getMongoConn()
        const db = conn.db()
        const paises = db.collection("paises")

        await paises.deleteMany({})

        const data = paises.find()

        for (let pais of paisArray) {
            await paises.insertOne(pais)
        }

    } catch (err) {
        console.log(err)
    } finally {
        conn?.close()
    }
}

main()