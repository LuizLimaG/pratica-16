import getMongoConn from './db';
import express, {Request, Response} from 'express'
import { MongoClient } from 'mongodb'
import cors from 'cors'

const app = express()
const port = 3000

app.use(cors())

app.get("/paises", async (req: Request, res: Response) => {

    const {populacao} = req.query

    let conn: MongoClient | null = null

    try {

        if (typeof populacao !== 'string') {
            throw new Error('O parâmetro população não foi informado')
        }

        const populacaoNumber = parseInt(populacao)

        if (isNaN(populacaoNumber)) {
            throw new Error('O parâmetro população não é um número')
        }

        try {

            conn = await getMongoConn()

            const db = conn.db()
            const paises = db.collection("paises")

            const docs = await paises.find({
                populacao: {$gte: populacaoNumber}
            }).toArray()

            res.status(200).json(docs)

        } catch (err) {
            res.status(500).json({
                message: (err as Error).message
            })
        } finally {
            conn?.close()
        }

    } catch (err) {
        res.status(400).json({message: (err as Error).message})
    }

})

app.listen(port, () => {
    console.log(`servidor iniciado na porta ${port}`)
})

 